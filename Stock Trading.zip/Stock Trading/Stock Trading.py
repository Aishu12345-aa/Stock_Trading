#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import threading
import random
import time

# Constants
MAX_TICKERS = 1024

# Global order book (a dictionary-like structure to store tickers and their orders)
# For simplicity, we will use a list of lists to simulate the order book for each ticker.
# Format: order_books[ticker_symbol] = {'buy_orders': [], 'sell_orders': []}
order_books = [None] * MAX_TICKERS

# Lock-free order book using a list of lists to simulate a simple order book.
class StockOrderBook:
    def __init__(self):
        # Initialize order book for each ticker
        self.buy_orders = []
        self.sell_orders = []

    def add_order(self, order_type, quantity, price):
        # Add order to the correct list (Buy/Sell)
        if order_type == 'Buy':
            self.buy_orders.append((price, quantity))
            # Sort buy orders in descending order of price to simulate market depth
            self.buy_orders.sort(reverse=True, key=lambda x: x[0])
        else:
            self.sell_orders.append((price, quantity))
            # Sort sell orders in ascending order of price to simulate market depth
            self.sell_orders.sort(key=lambda x: x[0])

    def match_orders(self):
        matched = []
        while self.buy_orders and self.sell_orders:
            # Check if the highest buy price >= lowest sell price
            buy_price, buy_qty = self.buy_orders[0]
            sell_price, sell_qty = self.sell_orders[0]

            if buy_price >= sell_price:
                matched_qty = min(buy_qty, sell_qty)
                # Record the matched order (price, quantity)
                matched.append((buy_price, matched_qty))

                # Update the quantities
                if buy_qty == matched_qty:
                    self.buy_orders.pop(0)
                else:
                    self.buy_orders[0] = (buy_price, buy_qty - matched_qty)

                if sell_qty == matched_qty:
                    self.sell_orders.pop(0)
                else:
                    self.sell_orders[0] = (sell_price, sell_qty - matched_qty)
            else:
                break
        return matched


def add_order_to_book(order_type, ticker_symbol, quantity, price):
    ticker_index = hash(ticker_symbol) % MAX_TICKERS
    if order_books[ticker_index] is None:
        order_books[ticker_index] = StockOrderBook()

    order_books[ticker_index].add_order(order_type, quantity, price)

def match_order_in_book(ticker_symbol):
    ticker_index = hash(ticker_symbol) % MAX_TICKERS
    if order_books[ticker_index] is None:
        return []

    return order_books[ticker_index].match_orders()

# Wrapper to simulate real-time active stock transactions
def simulate_stock_transactions():
    tickers = ["AAPL", "GOOG", "AMZN", "TSLA", "NFLX"]
    order_types = ["Buy", "Sell"]
    while True:
        ticker = random.choice(tickers)
        order_type = random.choice(order_types)
        price = random.randint(100, 1500)  # Random price for simplicity
        quantity = random.randint(1, 100)  # Random quantity for simplicity

        add_order_to_book(order_type, ticker, quantity, price)

        print(f"Added {order_type} order: Ticker={ticker}, Quantity={quantity}, Price={price}")
        time.sleep(1)  # Simulate time delay between orders

# Main execution
def main():
    # Start the simulation of stock transactions
    threading.Thread(target=simulate_stock_transactions, daemon=True).start()

    # Simulate matching orders every 3 seconds
    while True:
        for ticker_symbol in ["AAPL", "GOOG", "AMZN", "TSLA", "NFLX"]:
            matched = match_order_in_book(ticker_symbol)
            if matched:
                print(f"Matched Orders for {ticker_symbol}: {matched}")
        time.sleep(3)

if __name__ == "__main__":
    main()

